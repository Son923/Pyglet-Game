import pyglet


pyglet.resource.path = ['../resources']
pyglet.resource.reindex()
