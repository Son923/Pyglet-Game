import pyglet
import resources
import random


bird_flock = [[100, 300], [400, 300], [700, 300]]
for bird in range(len(bird_flock)):
    print(bird_flock[bird][0])
